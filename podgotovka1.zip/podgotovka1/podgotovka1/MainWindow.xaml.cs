﻿/*using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace podgotovka1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DGridHotels.ItemsSource = TurismEntities.GetContext().Hotel.ToList();
            this.MinHeight = 479.6;
            this.MinWidth = 800;
            /*MainFrame.Navigate(new ToursW()); 
            Manager.MainFrame = MainFrame;*

            ImportTours();
        }
        private void ImportTours()
        {
            var fileData = File.ReadAllLines(@"C:\Users\Гульфия\Desktop\Самостоятельная работа\Туры.txt");
            var images = Directory.GetFiles(@"C:\Users\Гульфия\Desktop\Самостоятельная работа\Самостоятельная работа\import\Туры фото");

            foreach (var line in fileData)
            {
                var data = line.Split('\t');

                var tempTour = new Tour
                {
                    Name = data[0].Replace("\"", ""),
                    TicketCount = int.Parse(data[2]),
                    Price = decimal.Parse(data[3]),
                    IsActual = (data[4] == "0") ? false : true
                };
                foreach (var tourType in data[5].Replace("\"", "").Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var currentType = TurismEntities.GetContext().Type.ToList().FirstOrDefault(p => p.Name == tourType);
                    if (currentType != null)
                        tempTour.Type.Add(currentType);
                }
                try 
                {
                    tempTour.ImagePreview = File.ReadAllBytes(images.FirstOrDefault(p => p.Contains(tempTour.Name)));
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                TurismEntities.GetContext().Tour.Add(tempTour);
                TurismEntities.GetContext().SaveChanges();
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            /*ToursW tours = new ToursW();
            tours.Show();
            this.Close();*
        }

        private void MainFrame_ContentRendered(object sender, EventArgs e)
        {
            if (MainFrame.CanGoBack)
            {
                BtnBack.Visibility = Visibility.Visible;
            }
            else 
            {
                BtnBack.Visibility = Visibility.Hidden;
            
            }
        }
    }
}*/
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace podgotovka1
{
    /// <summary>
    /// Логика взаимодействия для Hotels.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DGridHotels.ItemsSource = TurismEntities.GetContext().Hotel.ToList();
            this.MinHeight = 479.6;
            this.MinWidth = 800;
        }

      private void ImportTours()
        {
            var images = Directory.GetFiles(@"C:\Users\Гульфия\Desktop\Самостоятельная работа\Самостоятельная работа\import\Туры фото");
            using (TurismEntities db = new TurismEntities())
            {
                foreach (var item in db.Tour)
                {
                    try
                    {
                        item.ImagePreview = File.ReadAllBytes(images.FirstOrDefault(p => p.Contains(item.Name)));
                    }
                    catch
                    {
                        item.ImagePreview = null;
                    }
                }
                db.SaveChanges();
            }
        }
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            AddEditPage addEditPage = new AddEditPage((sender as Button).DataContext as Hotel);
            addEditPage.Show();
            this.Close();
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddEditPage addEditPage = new AddEditPage(null);
            addEditPage.Show();
            this.Close();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            
            var hotelsForRemoving = DGridHotels.SelectedItems.Cast<Hotel>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следущие {hotelsForRemoving.Count()} элементов?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    TurismEntities.GetContext().Hotel.RemoveRange(hotelsForRemoving);
                    TurismEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridHotels.ItemsSource = null;
                    DGridHotels.ItemsSource = TurismEntities.GetContext().Hotel.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTours_Click(object sender, RoutedEventArgs e)
        {
            ToursW tours = new ToursW();
            tours.Show();
            this.Close();
        }
    }
}
